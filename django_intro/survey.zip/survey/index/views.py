from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    return render(request,'index.html')

def result(request):
    if request.method=="POST":
        context={
            "name":request.POST["name"],
            "location":request.POST["location"],
            "fave_language":request.POST["fave_language"],
            "comment":request.POST["comment"],
            "gender":request.POST["gender"],

        }
        print(request.POST)
        return render(request, 'result.html', context)
