function showtime(){
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    return time
}